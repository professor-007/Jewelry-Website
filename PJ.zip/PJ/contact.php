<?php
// Define variables for form display and success message
$show_form = true;
$success_message = '';

// If the form is submitted
if(isset($_POST['submit'])){
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // You can perform additional validation here if needed

    // Set the success message and hide the form
    $success_message = 'Message sent! We will get in touch soon.';
    $show_form = false;
}
?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Pooja Jewellers</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
<meta name="author" content="freehtml5.co" />

<!-- 
//////////////////////////////////////////////////////

FREE HTML5 TEMPLATE 
DESIGNED & DEVELOPED by FreeHTML5.co
		
Website: 		http://freehtml5.co/
Email: 			info@freehtml5.co
Twitter: 		http://twitter.com/fh5co
Facebook: 		https://www.facebook.com/fh5co

//////////////////////////////////////////////////////
-->

<!-- Facebook and Twitter integration -->
<meta property="og:title" content=""/>
<meta property="og:image" content=""/>
<meta property="og:url" content=""/>
<meta property="og:site_name" content=""/>
<meta property="og:description" content=""/>
<meta name="twitter:title" content="" />
<meta name="twitter:image" content="" />
<meta name="twitter:url" content="" />
<meta name="twitter:card" content="" />

<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,600i,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Satisfy" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<!-- Animate.css -->
<link rel="stylesheet" href="css/animate.css">
<!-- Icomoon Icon Fonts-->
<link rel="stylesheet" href="css/icomoon.css">
<!-- Bootstrap  -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- Flexslider  -->
<link rel="stylesheet" href="css/flexslider.css">

<!-- Theme style  -->
<link rel="stylesheet" href="css/style.css">

<!-- Modernizr JS -->
<script src="js/modernizr-2.6.2.min.js"></script>
<!-- FOR IE9 below -->
<!--[if lt IE 9]>
<script src="js/respond.min.js"></script>
<![endif]-->

<style>
    .grey-textbox {
        background-color: #f2f2f2 !important; /* Grey background */
        color: black !important; /* Black text color */
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        margin-bottom: 10px;
    }

    .success-message {
        color: white;
        font-size: 30px;
        display: none;
    }

    .container {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .left {
        flex: 1;
        max-width: 50%;
        padding-right: 20px;
    }

    .right {
        flex: 1;
        max-width: 50%;
        padding-left: 20px;
    }

    @media (max-width: 768px) {
        .container {
            flex-direction: column;
        }

        .right {
            margin-left: 0;
            margin-top: 20px;
            padding-left: 0;
        }

        .left,
        .right {
            max-width: 100%;
            padding: 0;
        }
    }

    /* Custom submit button style */
    input[type="submit"] {
        background-color: #4CAF50; /* Green */
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    /* Change button color on hover */
    input[type="submit"]:hover {
        background-color: #45a049;
    }

    .instagram-icon {
			color: aliceblue;
            position: fixed;
            top: 5px; /* Adjust top position as needed */
            right: 70px; /* Adjust right position as needed */
    }

	.facebook-icon {
			color: aliceblue;
            position: fixed;
            top: 5px; /* Adjust top position as needed */
            right: 30px; /* Adjust right position as needed */
	}

	.mobile-icon {
            color: aliceblue;
            font-size: 16px; /* Adjust font size as needed */
            position: fixed;
            top: 10px; /* Adjust top position as needed */
            right: 270px; /* Adjust right position as needed */
    }

	.mobile-number {
            color: aliceblue;
            font-size: 16px; /* Adjust font size as needed */
            position: fixed;
            top: 5px; /* Adjust top position as needed */
            right: 160px; /* Adjust right position as needed */
    }



</style>
</head>
<body>

<div class="fh5co-loader"></div>

<div id="page">
			<nav class="fh5co-nav" role="navigation">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-center logo-wrap">
							<div>
								<h1 style="color: aliceblue;">POOJA JEWELLERS</h1>
								<span class="mobile-icon"><i class="fas fa-mobile-alt"></i></span>
								<span class="mobile-number"><h3 style="color: aliceblue;">7892217118</h3></span>
								<div class="instagram-icon">
										   
									<a href="https://www.instagram.com/pooja_jewellerss?igsh=NmNsZ3liM2swMXB6" style="font-size: 23px ; color: aliceblue;"><i class="fab fa-instagram"></i></a>
								   
								</div>
								<div class="facebook-icon">
										   
									<a href="https://www.instagram.com/pooja_jewellerss?igsh=NmNsZ3liM2swMXB6" style="font-size: 22px ; color: aliceblue;"><i class="fab fa-facebook"></i></a>
								   
								</div>
		
		
							</div>
							
						</div>
						<div class="col-xs-12 text-center menu-1 menu-wrap">
                            <ul>
                                <li><a href="index.html">Home</a></li>
                                <li><a href="menu.html">Designs</a></li>
                                <li class="has-dropdown">
                                <a href="gallery.html">Gallery</a>

                                </li>

                                <li><a href="about.html">About</a></li>
                                <li class="active"><a href="contact.php">Contact Us</a></li>

                            </ul>
                        </div>
					</div>
					
				</div>
			<!-- </div> -->
		</nav>

    <header id="fh5co-header" class="fh5co-cover js-fullheight" role="banner" style="background-image: url(images/2.jpg);" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="display-t js-fullheight">
                        <div class="display-tc js-fullheight animate-box" data-animate-effect="fadeIn">
                            <h1>Contact Us</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="left">
            <h2 style="color: white;">Get in touch</h2>
            <p>Message Us -> Have a question, suggestion, or just want to chat? We're all ears! Drop us a line using the form below, and we'll get back to you pronto. </p>
        </div>
        <div class="right"><br>
            <h2 style="color: white;">Contact Us</h2>
            <form id="contact-form" method="post">
                <label for="name">Name:</label><br>
                <input type="text" id="name" name="name" required class="grey-textbox"><br>
                <label for="email">Email:</label><br>
                <input type="email" id="email" name="email" required class="grey-textbox"><br>
                <label for="subject">Subject:</label><br>
                <input type="text" id="subject" name="subject" required class="grey-textbox"><br>
                <label for="message">Message:</label><br>
                <textarea id="message" name="message" required class="grey-textbox" style="height: 200px;"></textarea><br>
                <input type="submit" name="submit" value="Submit">
            </form>
            <p id="success-message" class="success-message">Message sent successfully!</p>
        </div>
    </div><br><br><br><br>

    <div class="container">
	    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6878.403078976561!2d77.60791812180577!3d12.908836213058859!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15031870ef67%3A0xf71026b82d0e458!2sPooja%20jewellers!5e0!3m2!1sen!2sin!4v1714386143820!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	</div>

	<footer id="fh5co-footer" role="contentinfo" class="fh5co-section">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-4 fh5co-widget">
					<h4>POOJA JEWELLERS</h4>
					<p>Crafted with passion and precision by skilled artisans, our jewelry transcends mere accessories to become cherished heirlooms, destined to be treasured for generations to come.</p>
				</div>
				<div class="col-md-2 col-md-push-1 fh5co-widget">
					<h4>Links</h4>
					<ul class="fh5co-footer-links">
						<li><a href="#">Home</a></li>
						<li><a href="#">Design</a></li>
						<li><a href="#">Gallery</a></li>
						<li><a href="#">About</a></li>
					</ul>
				</div>

				

				<div class="col-md-4 col-md-push-1 fh5co-widget">
					<h4>Contact Information</h4>
					<ul class="fh5co-footer-links">
						<li>16th Main Road <br>Near Mico Layout Police Station <br>BTM Layout 2nd Stage 560076</li>
						<li><a href="tel://1234567920">7892217118</a></li>
						<li><a href="mailto:info@yoursite.com">bharath12@gmail.com</a></li>
					</ul>
				</div>

				

			</div>

			

		</div>

        <div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; Pooja Jewellers. All Rights Reserved.</small> 
						<small class="block">Designed by Munesh Sagar , Shashank A Hebbar.</small>
					</p>
					
					
				</div>
			</div>

	</footer>
    </div>

<div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="icon-arrow-up22"></i></a>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="js/jquery.waypoints.min.js"></script>
<!-- Waypoints -->
<script src="js/jquery.stellar.min.js"></script>
<!-- Flexslider -->
<script src="js/jquery.flexslider-min.js"></script>
<!-- Main -->
<script src="js/main.js"></script>

<script>
    // JavaScript to handle form submission and success message display
    document.getElementById("contact-form").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent default form submission

        // Here you can add AJAX code to submit the form data to the server if needed
        
        // Display success message
        document.getElementById("success-message").style.display = "block";

        // Reset the form
        document.getElementById("contact-form").reset();
    });
</script>

</body>
</html>
